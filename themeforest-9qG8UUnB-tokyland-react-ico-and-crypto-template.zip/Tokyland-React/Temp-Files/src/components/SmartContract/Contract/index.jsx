const Contract = ({ img, title }) => {

  return (
    <div className="services-block-four v3">
      <div className="inner-box">
        <div className="icon-img-box">
          <img src={img} alt="" />
        </div>
        <h3><a href="#">{title}</a></h3>
        <div className="text">Lorem ipsum dolor sit amet, conse ctetur dolor adipisicing elit.</div>
      </div>
    </div>
  );
}

export default Contract;