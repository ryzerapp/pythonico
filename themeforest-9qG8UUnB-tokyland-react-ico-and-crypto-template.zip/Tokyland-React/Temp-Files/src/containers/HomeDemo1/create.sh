#!/bin/bash



mkdir TokenDistribution
cd TokenDistribution
echo TokenDistribution > index.jsx
cd ../

mkdir Roadmap
cd Roadmap
echo Roadmap > index.jsx
cd ../


mkdir Features2
cd Features2
echo Features2 > index.jsx
cd ../


mkdir Faq
cd Faq
echo Faq > index.jsx
cd ../


mkdir OurTeam
cd OurTeam
echo OurTeam > index.jsx
cd ../


mkdir Subscribe
cd Subscribe
echo Subscribe > index.jsx
cd ../


mkdir OurBlog
cd OurBlog
echo OurBlog > index.jsx
cd ../
