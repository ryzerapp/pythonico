import {
	SecHeadingSectionIcon1,
	HomePageDemo1,
	HomePageDemo2,
	HomePageDemo3
    
} from '../../utils/allImgs'

export const data = [ 
		{
			imgDemo:HomePageDemo1,
			path:"/index-demo-1"
		}, 
		{
			imgDemo:HomePageDemo2,
			path:"/index-demo-2"
		}, 
		{
			imgDemo:HomePageDemo3,
			path:"/index-demo-3"
		}	
]

export const imgSecHeading = SecHeadingSectionIcon1