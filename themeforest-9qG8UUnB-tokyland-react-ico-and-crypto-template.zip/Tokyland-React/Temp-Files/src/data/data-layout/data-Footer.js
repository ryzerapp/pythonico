import{

	// FooterWithTestImg1,
	// FooterWithTestImg2,
	// FooterWithTestImg3,

 //    FAQMember1,
 //    FAQMember2,
 //    FAQMember3,
 //    FAQMember4,

	// FooterPagesPartners1,
	// FooterPagesPartners2,
	// FooterPagesPartners3,
	// FooterPagesPartners4,
	// FooterPagesPartners5,
} from '../../utils/allImgs'

export const IcoName = [
	{IcoName:'fa fa-facebook'},
	{IcoName:'fa fa-twitter'},
	{IcoName:'fa fa-google-plus'},
	{IcoName:'fa fa-instagram'},
	{IcoName:'fa fa-linkedin'}
]

export const TextFooter = [
	{
		title:'PRIVACY &amp; TOS',
		text1:'Advertiser Agreement',
		text2:'Acceptable Use Policy',
		text3:'Privacy Policy',
		text4:'Technology Privacy',
		text5:'Developer Agreement',
        classBlock:"col-12 col-lg-3 col-md-6",
        classInfo:"contact_info mt-x text-center fadeInUp",
	},
	{
		title:'NAVIGATE',
		text1:'Advertisers',
		text2:'Developers',
		text3:'Resources',
		text4:'Company',
		text5:'Connect',
        classBlock:"col-12 col-lg-2 col-md-6",
        classInfo:"contact_info mt-s text-center fadeInUp",
	},
	{
		title:'CONTACT US',
		text1:'Mailing Address:xx00 E. Union Ave',
		text2:'Suite 1100. Denver, CO 80237',
		text3:'+999 90932 627',
		text4:'support@yourdomain.com',
        classBlock:"col-12 col-lg-3 col-md-6",
        classInfo:"contact_info mt-s text-center fadeInUp",
		text5:false
	},
]

// export const TestimonialContent = [
//     {
//         img:FooterWithTestImg1,
//         name:'Sunny Khan',
//         title:'Head of Design, Company CEO'
//     },
//     {
//         img:FooterWithTestImg2,
//         name:'Ajoy Das',
//         title:'Head of Idea, Company CEO'
//     },
//     {
//         img:FooterWithTestImg3,
//         name:'Jebin Khan',
//         title:'Head of Marketing, Company CEO'
//     },
// ]

// export const FQAInfo = [
//     {
//         text:'What are the objectives of this token?',
//         ID:'Q1'
//     },
//     {
//         text:'What is Token Sale and pre-sale?',
//         ID:'Q2'
//     },
//     {
//         text:'What is the pre-sale start date?',
//         ID:'Q3'
//     },
//     {
//         text:'how may I take part in pre-sale?',
//         ID:'Q4'
//     },
//     {
//         text:'What is the best features and services we deiver?',
//         ID:'Q5'
//     },
// ]

// export const TeamMemberContent = [
//     {
//         img:FAQMember1,
//         name:'Randy crishen',
//         title:'Company CEO'
//     },
//     {
//         img:FAQMember2,
//         name:'Monica Ashker',
//         title:'Web Designer'
//     },
//     {
//         img:FAQMember3,
//         name:'Tollay Ramzomi',
//         title:'Web Developer'
//     },
//     {
//         img:FAQMember4,
//         name:'Jacke Wilson',
//         title:'Marketing Specialist'
//     },
// ]